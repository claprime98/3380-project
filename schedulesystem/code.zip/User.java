package schedulesystem;

import java.util.ArrayList;

public class User {
    
    ArrayList<Course> completed;
    ArrayList<Course> registered;
    
    public User() {
        
    }
}
